import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { services } from "@/lib/services";
import { submitQuoteRequest } from "@/lib/quote.functions";

const field =
  "w-full rounded-sm border border-ink/20 bg-ink-foreground/5 px-4 py-3 text-ink placeholder:text-ink/40 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30";

export function QuoteForm() {
  const send = useServerFn(submitQuoteRequest);
  const [state, setState] = useState<"idle" | "sending" | "done">("idle");
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = e.currentTarget;
    const raw = Object.fromEntries(new FormData(form).entries());
    const value = {
      name: String(raw["name"] ?? ""),
      email: String(raw["email"] ?? ""),
      phone: String(raw["phone"] ?? ""),
      company: String(raw["company"] ?? ""),
      service: String(raw["service"] ?? ""),
      details: String(raw["details"] ?? ""),
    };
    setState("sending");
    try {
      await send({ data: value });
      setState("done");
      form.reset();
    } catch (err) {
      setError(
        err instanceof Error && err.message
          ? err.message
          : "We couldn't send that. Please call us and we'll take it from there.",
      );
      setState("idle");
    }
  }

  if (state === "done") {
    return (
      <div className="rounded-sm border-2 border-ink/15 bg-ink-foreground p-10 text-center text-ink">
        <div className="font-display text-3xl text-primary">Request received.</div>
        <p className="mx-auto mt-3 max-w-md opacity-80">
          Thanks — we've got your details. Expect a written quote within about two
          business days. If it's urgent, call us and mention your name.
        </p>
        <button
          type="button"
          onClick={() => setState("idle")}
          className="mt-6 font-bold uppercase tracking-wide text-primary hover:underline"
        >
          Send another request
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
      <label className="block">
        <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-ink/70">
          Your name
        </span>
        <input name="name" required placeholder="Jordan Alvarez" className={field} />
      </label>
      <label className="block">
        <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-ink/70">
          Email
        </span>
        <input
          name="email"
          type="email"
          required
          placeholder="you@company.com"
          className={field}
        />
      </label>
      <label className="block">
        <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-ink/70">
          Phone (optional)
        </span>
        <input name="phone" placeholder="(713) 555-0142" className={field} />
      </label>
      <label className="block">
        <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-ink/70">
          Company (optional)
        </span>
        <input name="company" placeholder="Alvarez Dental" className={field} />
      </label>
      <label className="block sm:col-span-2">
        <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-ink/70">
          What do you need?
        </span>
        <select name="service" required className={field} defaultValue="">
          <option value="" disabled>
            Choose a sign type
          </option>
          {services.map((s) => (
            <option key={s.slug} value={s.title}>
              {s.title}
            </option>
          ))}
          <option value="Not sure yet">Not sure yet — help me decide</option>
        </select>
      </label>
      <label className="block sm:col-span-2">
        <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-ink/70">
          Tell us about the job
        </span>
        <textarea
          name="details"
          required
          rows={4}
          placeholder="Building address, approximate size, whether it needs to be lit, and when you'd like it installed."
          className={field}
        />
      </label>

      {error && (
        <p className="sm:col-span-2 rounded-sm border border-primary/40 bg-primary/10 px-4 py-3 text-sm font-semibold text-primary">
          {error}
        </p>
      )}

      <div className="sm:col-span-2">
        <button
          type="submit"
          disabled={state === "sending"}
          className="w-full rounded-sm bg-primary px-8 py-4 font-bold uppercase tracking-wide text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60 sm:w-auto"
        >
          {state === "sending" ? "Sending…" : "Request My Free Quote"}
        </button>
        <p className="mt-3 text-xs text-ink/80">
          No obligation. We reply with a written quote, usually within two business
          days.
        </p>
      </div>
    </form>
  );
}
